package entity;

public class OrderDone{
	private String ordersn;
	private String goodsid;
	private String goodsname;
	private String goodspic;
	private String goodsprice;
	private String shoppingnum;

	public String getOrdersn() {
		return ordersn;
	}
	public void setOrdersn(String ordersn) {
		this.ordersn = ordersn;
	}
	public String getGoodsid() {
		return goodsid;
	}
	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}
	public String getGoodsname() {
		return goodsname;
	}
	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}
	public String getGoodspic() {
		return goodspic;
	}
	public void setGoodspic(String goodspic) {
		this.goodspic = goodspic;
	}
	public String getGoodsprice() {
		return goodsprice;
	}
	public void setGoodsprice(String goodsprice) {
		this.goodsprice = goodsprice;
	}
	public String getShoppingnum() {
		return shoppingnum;
	}
	public void setShoppingnum(String shoppingnum) {
		this.shoppingnum = shoppingnum;
	}
	
	
}