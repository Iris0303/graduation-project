package entity;

public class Goods {
	private String goodsid;
	private String goodsname;
	private String goodstype;
	private String goodspic;
	private String goodsprice;
	private String goodsdiscription;
	public String getGoodsid() {
		return goodsid;
	}
	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}
	public String getGoodsname() {
		return goodsname;
	}
	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}
	public String getGoodstype() {
		return goodstype;
	}
	public void setGoodstype(String goodstype) {
		this.goodstype = goodstype;
	}
	public String getGoodspic() {
		return goodspic;
	}
	public void setGoodspic(String goodspic) {
		this.goodspic = goodspic;
	}
	public String getGoodsprice() {
		return goodsprice;
	}
	public void setGoodsprice(String goodsprice) {
		this.goodsprice = goodsprice;
	}
	

	public String getGoodsdiscription() {
		return goodsdiscription;
	}
	public void setGoodsdiscription(String goodsdiscription) {
		this.goodsdiscription = goodsdiscription;
	}
	
	
}
