package entity;

public class CartGoods {
	private String goodsid ;
	private String goodsname ;
	private String goodspic  ;
	private String goodsprice ;
	private String shoppingnum ;
	private String singlsum ;
	private String total;
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getGoodsid() {
		return goodsid;
	}
	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}
	public String getGoodsname() {
		return goodsname;
	}
	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}
	public String getGoodspic() {
		return goodspic;
	}
	public void setGoodspic(String goodspic) {
		this.goodspic = goodspic;
	}
	public String getGoodsprice() {
		return goodsprice;
	}
	public void setGoodsprice(String goodsprice) {
		this.goodsprice = goodsprice;
	}
	public String getShoppingnum() {
		return shoppingnum;
	}
	public void setShoppingnum(String shoppingnum) {
		this.shoppingnum = shoppingnum;
	}
	public String getSinglsum() {
		return singlsum;
	}
	public void setSinglsum(String singlsum) {
		this.singlsum = singlsum;
	}
	
}
