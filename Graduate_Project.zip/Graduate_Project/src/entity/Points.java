package entity;
public class Points
{
	private String pno;
	private String prizename;
	private String prizedes;
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	public String getPrizename() {
		return prizename;
	}
	public void setPrizename(String prizename) {
		this.prizename = prizename;
	}
	public String getPrizedes() {
		return prizedes;
	}
	public void setPrizedes(String prizedes) {
		this.prizedes = prizedes;
	}
	
}