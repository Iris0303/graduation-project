package entity;
public class workTime{
	private String tno;
	private String no;
	private String tdate;
	private String tday;
	private String tnight;
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getTday() {
		return tday;
	}
	public void setTday(String tday) {
		this.tday = tday;
	}
	public String getTnight() {
		return tnight;
	}
	public void setTnight(String tnight) {
		this.tnight = tnight;
	}
	
	
}