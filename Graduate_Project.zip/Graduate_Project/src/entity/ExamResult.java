package entity;
public class ExamResult
{
	private String tno;
	private String tname;
	private String tsuggest;
	private String tcontent;
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTsuggest() {
		return tsuggest;
	}
	public void setTsuggest(String tsuggest) {
		this.tsuggest = tsuggest;
	}
	public String getTcontent() {
		return tcontent;
	}
	public void setTcontent(String tcontent) {
		this.tcontent = tcontent;
	}
	
	
}