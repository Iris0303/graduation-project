package entity;

public  class Exam
{
	private String tno;
	private String ttest;
	private String ta;
	private String tb;
	private String tc;
	private String td;
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTtest() {
		return ttest;
	}
	public void setTtest(String ttest) {
		this.ttest = ttest;
	}
	public String getTa() {
		return ta;
	}
	public void setTa(String ta) {
		this.ta = ta;
	}
	public String getTb() {
		return tb;
	}
	public void setTb(String tb) {
		this.tb = tb;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getTd() {
		return td;
	}
	public void setTd(String td) {
		this.td = td;
	}
	
	
}