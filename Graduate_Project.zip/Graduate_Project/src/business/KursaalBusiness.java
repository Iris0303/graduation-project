package business;

public class KursaalBusiness extends BaseBusiness{
	
}