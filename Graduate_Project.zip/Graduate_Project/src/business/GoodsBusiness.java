package business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import entity.CartGoods;
//import entity.Course;
import entity.Goods;
import entity.OrderDone;
import entity.Points;

public class GoodsBusiness extends BaseBusiness{
	
	public ArrayList<Goods> getAllGoods(){
		
		ArrayList<Goods> al=new ArrayList<Goods>();
		
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		try {
			pst=con.prepareStatement("select * from t_goodsTable");
			rs=pst.executeQuery();
			while(rs.next()){
				Goods g=new Goods();
				g.setGoodsid(rs.getString(1));
				g.setGoodsname(rs.getString(2));
				g.setGoodstype(rs.getString(3));
				g.setGoodspic(rs.getString(4));
				g.setGoodsprice(rs.getString(5));

				g.setGoodsdiscription(rs.getString(6));
				al.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close(rs);
			close(pst);
			close(con);
		}
		return al;
	}
	
	
	public Goods getAgoods(String id){
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		Goods g=new Goods();
		try {
			pst=con.prepareStatement("select * from t_goodsTable where goodsid=?");
			pst.setString(1, id);
			rs=pst.executeQuery();
			while(rs.next()){
				
				g.setGoodsid(rs.getString(1));
				g.setGoodsname(rs.getString(2));
				g.setGoodstype(rs.getString(3));
				g.setGoodspic(rs.getString(4));
				g.setGoodsprice(rs.getString(5));
				g.setGoodsdiscription(rs.getString(6));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close(rs);
			close(pst);
			close(con);
		}
		return g;
	}
	
	public boolean isexit(String goodsid,String sessionid){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=con.prepareStatement("select * from t_cartTable tc,t_cartRecord tr" +
					" where tc.sessionid=?" +
					" and tc.isorder='0'" +
					" and tr.sessionid=tc.sessionid" +
					" and tr.goodsid=?");
			pst.setString(1, sessionid);
			pst.setString(2, goodsid);
			rs=pst.executeQuery();
			if(rs.next()){
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close(rs);
			close(pst);
			close(con);
		}		
		return b;
	}
	
	public boolean isCartexit(String sessionid){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=con.prepareStatement("select * from t_cartTable" +
					" where sessionid=?" +
					" and isorder='0'");
			pst.setString(1, sessionid);
			rs=pst.executeQuery();
			if(rs.next()){
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close(rs);
			close(pst);
			close(con);
		}		
		return b;
	}
	
	public boolean updatecart(String goodsid,String sessionid,int mkrum){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("update t_cartRecord set" +
					" shoppingnum=shoppingnum+?" +
					" where goodsid=? and sessionid =?");
			pst.setInt(1, mkrum);
			pst.setString(2, goodsid);
			pst.setString(3, sessionid);
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}
	
	
	
	
	public boolean addcart(String goodsid,String sessionid,int mkrum){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("insert into t_cartRecord(" +
					"	sessionid," +
					"	goodsid," +
					"	goodsname," +
					"	goodspic," +
					"	goodsprice," +
					"	shoppingnum " +
					"	) " +
					" select '" +sessionid+"',"+
					" 	 goodsid,goodsname,goodspic,goodsprice,"+mkrum+" from t_goodsTable"+
					  " where goodsid='" +goodsid+"'"
					);
		
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}
	
	public boolean createcart(String sessionid,String username){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("insert into t_cartTable(" +
					"	sessionid," +
					"	userName," +
					"	isorder," +
					"	createtime)" +
					" 	values(?,?,?,sysdate) " 
					);
			pst.setString(1, sessionid);
			pst.setString(2, username);
			pst.setString(3, "0");
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}
	
	public ArrayList<CartGoods> getCartAllGoods(String sessionid){
		
		ArrayList<CartGoods> al=new ArrayList<CartGoods>();
		
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		try {
			pst=con.prepareStatement("select " +
					"	tr.goodsid,tr.goodsname,tr.goodspic,tr.goodsprice,tr.shoppingnum,tr.shoppingnum*tr.goodsprice, tt.total" +
					"	from t_cartTable tc, t_cartRecord tr," +
					" (select sum(tr.shoppingnum*tr.goodsprice) as total from " +
					"  t_cartTable tc, t_cartRecord tr " +
					" where tc.sessionid=? and tc.isorder='0' and tr.sessionid=tc.sessionid " +
					") tt" +
					" where tc.sessionid=? and tc.isorder='0' and tr.sessionid=tc.sessionid " );
			pst.setString(1, sessionid);
			pst.setString(2, sessionid);
			rs=pst.executeQuery();
			while(rs.next()){
				CartGoods g=new CartGoods();
				g.setGoodsid(rs.getString(1));
				g.setGoodsname(rs.getString(2));
				g.setGoodspic(rs.getString(3));
				g.setGoodsprice(rs.getString(4));
				g.setShoppingnum(rs.getString(5));
				g.setSinglsum(rs.getString(6));
				g.setTotal(rs.getString(7));
				al.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close(rs);
			close(pst);
			close(con);
		}
		return al;
	}
	
	public boolean addOrder(String sessionid,String goodsamount,String ordersn,String username){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("insert into t_order_info values(?,?,?,?,SYSDATE)");
			pst.setString(1, ordersn);
			pst.setString(2, username);
			pst.setString(3, goodsamount);
			pst.setString(4, "0");
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}

	public boolean addOrderRecord(String sessionid,String ordersn){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("insert into t_order_record(" +
					"	ordersn," +
					"	goodsid," +
					"	goodsname," +
					"	goodspic," +
					"	goodsprice," +
					"	shoppingnum " +
					"	) " +
					" select '" +ordersn+"',"+
					" 	 tr.goodsid,tr.goodsname,tr.goodspic,tr.goodsprice,tr.shoppingnum from t_cartRecord tr,t_cartTable tc"+
					  " where tc.sessionid='" +sessionid+"'  and tr.sessionid=tc.sessionid  and tc.isorder='0'"
					);
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}

	public boolean updateCartStatus(String sessionid){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("delete from  t_cartTable  where sessionid=? ");
			pst.setString(1, sessionid);
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}	
	
	public boolean updateCartRecordStatus(String sessionid){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			pst=con.prepareStatement("delete from  t_cartRecord  where sessionid=? ");
			pst.setString(1, sessionid);
			int i=pst.executeUpdate();
			if(i>0)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}		
		return b;
	}	
	

	//ɾ����Ʒ��Ϣ
  public void deleteGoods(String sessionid,String goodsid)
	{
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="delete from t_cartRecord where sessionid=? and goodsid=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, sessionid);
			pst.setString(2, goodsid);
			pst.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
	}
	
public ArrayList<OrderDone> getOrderDone(String userName){
		
		ArrayList<OrderDone> od=new ArrayList<OrderDone>();
		
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		try {
			pst=con.prepareStatement("select t_order_record.ordersn,t_order_record.goodsid,t_order_record.goodsname,t_order_record.goodsname,t_order_record.goodsprice,t_order_record.shoppingnum" +
					" from t_order_info,t_order_record" +
					" where t_order_info.ordersn=t_order_record.ordersn and t_order_info.userName=?");
			pst.setString(1, userName);
			rs=pst.executeQuery();
			while(rs.next()){
				OrderDone o=new OrderDone();
				o.setOrdersn(rs.getString(1));
				o.setGoodsid(rs.getString(2));
				o.setGoodsname(rs.getString(3));
				o.setGoodspic(rs.getString(4));
				o.setGoodsprice(rs.getString(5));
				o.setShoppingnum(rs.getString(6));
				od.add(o);
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close(rs);
			close(pst);
			close(con);
		}
		return od;
	}

public int getPoints(String username){
	Connection con=getOneCon();
	PreparedStatement pst=null;
	ResultSet rs=null;
	int s=0;
	try {
		pst=con.prepareStatement("select sum(goodsamount) from t_order_info where username=?");
		pst.setString(1, username);
		rs=pst.executeQuery();
		while(rs.next()){
			s=rs.getInt(1);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		close(rs);
		close(pst);
		close(con);
	}
	return s;
}

public ArrayList<Points> getPrize(String pname)
{
	ArrayList<Points> aq=new ArrayList<Points>();
	Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
	PreparedStatement pst=null;
	ResultSet rs=null;
	try {
		String sql="select prize.pno,prize.prizename,prize.prizedes from points,prize where points.pno=prize.pno and points.pname=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,pname);
		rs=pst.executeQuery();        //ִ�в�ѯ
		while(rs.next())
		{
			Points p=new Points();
			p.setPno(rs.getString(1));
			p.setPrizename(rs.getString(2));
			p.setPrizedes(rs.getString(3));
			aq.add(p);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally
	{
		close(rs);
		close(pst);
		close(con);
	}
	return aq;
}

}
