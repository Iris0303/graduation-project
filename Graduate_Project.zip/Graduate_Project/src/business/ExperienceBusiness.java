package business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import entity.Exam;
import entity.ExamResult;



public class ExperienceBusiness extends BaseBusiness {
	
	//�õ�������
	public ArrayList<Exam>  getAll()
	{
		ArrayList<Exam> ae=new ArrayList<Exam>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select * from exam";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				Exam ex=new Exam();
				ex.setTno(rs.getString(1));
				ex.setTtest(rs.getString(2));
				ex.setTa(rs.getString(3));
				ex.setTb(rs.getString(4));
				ex.setTc(rs.getString(5));
				ex.setTd(rs.getString(6));
				ae.add(ex);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return ae;
	}
	
	//�õ����Խ��
	public ExamResult getResult(String tno)
	{
		ExamResult er=new ExamResult();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select * from result where tno=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, tno);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				er.setTno(rs.getString(1));
				er.setTname(rs.getString(2));
				er.setTsuggest(rs.getString(3));
				er.setTcontent(rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return er;
	}
}
