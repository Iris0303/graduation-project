package business;
import java.sql.*;
import java.util.ArrayList;


import entity.Data;
import entity.Experience;
import entity.User;
import entity.allOrder;

import struts.form.AddExperienceForm;
import struts.form.AddShopForm;
import struts.form.MRegistForm;
import struts.form.MloginForm;
import struts.form.ModifyActivityForm;
import struts.form.ModifyExperienceForm;
import struts.form.ModifyShopForm;
import struts.form.ModifyUserForm;
import struts.form.UpdateDataForm;

public class MBusiness extends BaseBusiness{

	//�ж��û����Ƿ����
	public boolean isUse(String uname){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM managertable WHERE userName=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, uname);
			rs=pst.executeQuery();
			//�ж�����ֵ
			if(rs.next()){
				b=false;
			}else{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		    close(rs);
		    close(pst);
		    close(con);
		}
		return b;
		
	}
	
	//ʵ��ע�Ṧ��
	public boolean regist(MRegistForm u){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			String sql="INSERT INTO managertable VALUES(?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getUname());
			pst.setString(2, u.getUpass());
			pst.setString(3, u.getId());
			pst.setString(4, u.getTelephone());
			pst.setString(5, u.getMail());
			pst.setString(6, u.getAddress());
			pst.setString(7, u.getPosition());
			pst.setString(8, u.getDescription());
			int n=pst.executeUpdate();
			if(n>0){
				b=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		    
		    close(pst);
		    close(con);
		}
		return b;
		
	}
	
	//ʵ�ֵ�¼����

	public boolean islogin(MloginForm u){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM managertable WHERE userName=? and password=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getUname());
			pst.setString(2, u.getUpass());
			rs=pst.executeQuery();
			//�ж�����ֵ
			if(rs.next()){
				b=true;
			}else{
				b=false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		    close(rs);
		    close(pst);
		    close(con);
		}
		return b;
		
	}
	
	//�޸ĸ�������
	public boolean updatePassword(String uname,String u){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		try {
			String sql="update managertable set password=? where username=?";
			pst=con.prepareStatement(sql);
			
			pst.setString(1,u);
			pst.setString(2,uname);
			

			int n=pst.executeUpdate();
			if(n>0){
				b=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			close(pst);
			close(con);
		}
		return b;
		
	}
	
	//�õ�����Ա������Ϣ
	public Data getInfo(String username)
	{
		Data f=new Data();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select id,telephone,mail,address,position,description from managertable where username=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, username);        //���кţ����Ĳ�����
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				f.setId(rs.getString(1));
				f.setTelephone(rs.getString(2));
				f.setMail(rs.getString(3));
				f.setAddress(rs.getString(4));
				f.setPosition(rs.getString(5));
				f.setDescription(rs.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return f;
	}
	
	//�޸Ĺ���Ա��Ϣ
	public boolean updateData(UpdateDataForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update managertable set telephone=?,mail=?,address=?,position=?, description=? where id=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getTelephone());
			pst.setString(2, f.getMail());
			pst.setString(3, f.getAddress());
			pst.setString(4, f.getPosition());
			pst.setString(5, f.getDescription());
			pst.setString(6, f.getId());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//��ѯ�����û���Ϣ
	public ArrayList<User> getAllUser()
	{
		ArrayList<User> au=new ArrayList<User>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select * from usertable";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				User u=new User();
				u.setUserName(rs.getString(1));
				u.setPassword(rs.getString(2));
				u.setId(rs.getString(3));
				u.setTelephone(rs.getString(4));
				u.setMail(rs.getString(5));
				u.setAddress(rs.getString(6));
				u.setPosition(rs.getString(7));
				u.setDescription(rs.getString(8));
				au.add(u);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return au;
	}
	
	//�õ�һ���û�����Ϣ
	public User getAUser(String id)
	{
		User u=new User();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select* from usertable where id=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, id);        //���кţ����Ĳ�����
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				u.setUserName(rs.getString(1));
				u.setPassword(rs.getString(2));
				u.setId(rs.getString(3));
				u.setTelephone(rs.getString(4));
				u.setMail(rs.getString(5));
				u.setAddress(rs.getString(6));
				u.setPosition(rs.getString(7));
				u.setDescription(rs.getString(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return u;
	}
	
	//�޸��û���Ϣ
	public boolean modifyUser(ModifyUserForm m)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update usertable set password=?,telephone=?,mail=?,address=?,position=?,description=? where id=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, m.getPassword());
			pst.setString(2, m.getTelephone());
			pst.setString(3, m.getMail());
			pst.setString(4, m.getAddress());
			pst.setString(5, m.getPosition());
			pst.setString(6, m.getDescription());
			pst.setString(7, m.getId());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//����Ա�޸��û�������Ϣ
	public boolean managerMU(ModifyUserForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update usertable set username=?,password=?,telephone=?,mail=?,address=?,position=?, description=? where id=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getUserName());
			pst.setString(2, f.getPassword());
			pst.setString(3, f.getTelephone());
			pst.setString(4, f.getMail());
			pst.setString(5, f.getAddress());
			pst.setString(6, f.getPosition());
			pst.setString(7, f.getDescription());
			pst.setString(8, f.getId());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//����Աɾ���û�
	public boolean deleteUser(String id){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from usertable where id=?");
			pst.setString(1, id);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
	
	//ʵ��������Ʊ��Ϣ
	public boolean addShop(AddShopForm f)
	{
		boolean b=false;
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="INSERT INTO t_goodstable values(?,?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, f.getGoodsid());
			pst.setString(2, f.getGoodsname());
			pst.setString(3, f.getGoodstype());
			pst.setString(4, f.getGoodspic());
			pst.setString(5, f.getGoodsprice());
			pst.setString(6, f.getGoodsdiscription());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//ɾ����Ʊ
	public boolean deleteShop(String goodsid){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from t_goodstable where goodsid=?");
			pst.setString(1, goodsid);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
	
	//�޸���Ʊ��Ϣ
	public boolean modifyGoods(ModifyShopForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update t_goodstable set goodsname=?,goodstype=?,goodspic=?,goodsprice=?,goodsdiscription=? where goodsid=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getGoodsname());
			pst.setString(2, f.getGoodstype());
			pst.setString(3, f.getGoodspic());
			pst.setString(4, f.getGoodsprice());
			pst.setString(5, f.getGoodsdiscription());
			pst.setString(6, f.getGoodsid());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//�޸����»��Ϣ
	public boolean modifyActivity(ModifyActivityForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update activity set title=?,content=?,time=? where no=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getTitle());
			pst.setString(2, f.getContent());
			pst.setString(3, f.getTime());
			pst.setString(4, f.getNo()); 
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//����԰����Ϣ
	public boolean addExperience(AddExperienceForm f)
	{
		boolean b=false;
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="INSERT INTO experience values(?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, f.getNo());
			pst.setString(2, f.getName());
			pst.setString(3, f.getContent());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//��ѯ�����û���Ϣ
	public ArrayList<Experience> getAllExperience()
	{
		ArrayList<Experience> au=new ArrayList<Experience>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select * from experience order by no asc";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				Experience e=new Experience();
				e.setNo(rs.getString(1));
				e.setName(rs.getString(2));
				e.setContent(rs.getString(3));
				au.add(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return au;
	}
	
	//�õ�һ��԰����Ϣ
	public Experience getAExperience(String no)
	{
		Experience ex=new Experience();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select* from experience where no=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, no);        //���кţ����Ĳ�����
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				ex.setNo(rs.getString(1));
				ex.setName(rs.getString(2));
				ex.setContent(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return ex;
	}
	
	//�޸�԰����Ϣ
	public boolean modifyExperience(ModifyExperienceForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update experience set name=?,content=? where no=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getName());
			pst.setString(2, f.getContent());
			pst.setString(3, f.getNo());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//ɾ��԰����Ϣ
	public boolean deleteExperience(String no){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from experience where no=?");
			pst.setString(1, no);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
	
	//��ѯĳһ���û�����
	public ArrayList<allOrder> getAllOrder(String name)
	{
		ArrayList<allOrder> ao=new ArrayList<allOrder>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select ordersn,addtime from t_order_info where username=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, name);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				allOrder a=new allOrder();
				a.setOrdersn(rs.getString(1));
				a.setAddtime(rs.getString(2));
				ao.add(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return ao;
	}
	
	//ɾ������
	public boolean deleteOrder(String ordersn){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from t_order_info where ordersn=?");
			pst.setString(1, ordersn);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
}
