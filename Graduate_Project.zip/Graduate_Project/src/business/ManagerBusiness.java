package business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import struts.form.AddActivityForm;
import struts.form.AddTMForm;
import struts.form.AddWorkTimeForm;
import struts.form.ModifyTMForm;
import struts.form.ModifyWorkTimeForm;



import entity.Activity;
import entity.TM;
import entity.workTime;


public class ManagerBusiness extends BaseBusiness {

	//ɾ������
	public boolean deleteMessage(String id){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from message where id=?");
			pst.setString(1, id);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
	//ʵ������Ӫҵ��Ϣ
	public boolean addWorkTime(AddWorkTimeForm f)
	{
		boolean b=false;
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="INSERT INTO timedata values(?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, f.getTno());
			pst.setString(2, f.getNo());
			pst.setString(3, f.getTdate());
			pst.setString(4, f.getTday());
			pst.setString(5, f.getTnight());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//ɾ������
	public boolean deleteWorkTime(String no,String tno){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from timedata where no=? and tno=?");
			pst.setString(1, no);
			pst.setString(2, tno);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
	//��ѯworkTime1-4
	public ArrayList<workTime> getAllworkTime()
	{
		ArrayList<workTime> wt=new ArrayList<workTime>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM timedata where tno='01'";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				workTime w=new workTime();
				w.setTno(rs.getString(1));
				w.setNo(rs.getString(2));
				w.setTdate(rs.getString(3));
				w.setTday(rs.getString(4));
				w.setTnight(rs.getString(5));
				wt.add(w);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return wt;
	}
	
	public ArrayList<workTime> getAllworkTime2()
	{
		ArrayList<workTime> wt=new ArrayList<workTime>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM timedata where tno='02'";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				workTime w=new workTime();
				w.setTno(rs.getString(1));
				w.setNo(rs.getString(2));
				w.setTdate(rs.getString(3));
				w.setTday(rs.getString(4));
				w.setTnight(rs.getString(5));
				wt.add(w);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return wt;
	}
	
	public ArrayList<workTime> getAllworkTime3()
	{
		ArrayList<workTime> wt=new ArrayList<workTime>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM timedata where tno='03'";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				workTime w=new workTime();
				w.setTno(rs.getString(1));
				w.setNo(rs.getString(2));
				w.setTdate(rs.getString(3));
				w.setTday(rs.getString(4));
				w.setTnight(rs.getString(5));
				wt.add(w);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return wt;
	}
	
	public ArrayList<workTime> getAllworkTime4()
	{
		ArrayList<workTime> wt=new ArrayList<workTime>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM timedata where tno='04'";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				workTime w=new workTime();
				w.setTno(rs.getString(1));
				w.setNo(rs.getString(2));
				w.setTdate(rs.getString(3));
				w.setTday(rs.getString(4));
				w.setTnight(rs.getString(5));
				wt.add(w);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return wt;
	}
	
	//��ѯһ��WorkTime
	public workTime getOneWorkTime(String tno, String no)
	{
		workTime w=new workTime();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM timedata"
				          +" WHERE tno=? and no=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, tno);        //���кţ����Ĳ�����
			pst.setString(2, no);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				w.setTno(rs.getString(1));
				w.setNo(rs.getString(2));
				w.setTdate(rs.getString(3));
				w.setTday(rs.getString(4));
				w.setTnight(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return w;
	}
	//�޸�WorkTime 1-4
	
	//ʵ���������»��Ϣ
	public boolean addActivity(AddActivityForm f)
	{
		boolean b=false;
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="INSERT INTO activity values(?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, f.getNo());
			pst.setString(2, f.getTitle());
			pst.setString(3, f.getContent());
			pst.setString(4, f.getTime());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//ʵ�ֲ�ѯActivity��Ϣ
	public ArrayList<Activity> getAllActivity()
	{
		ArrayList<Activity> at=new ArrayList<Activity>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM activity order by no desc";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				Activity t=new Activity();
				t.setNo(rs.getString(1));
				t.setTitle(rs.getString(2));
				t.setContent(rs.getString(3));
				t.setTime(rs.getString(4));
				at.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return at;
	}
	
	//��ѯһ�����»��Ϣ
	public Activity getAactivity(String no)
	{
		Activity t=new Activity();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM activity WHERE no=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, no);        //���кţ����Ĳ�����
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				t.setNo(rs.getString(1));
				t.setTitle(rs.getString(2));
				t.setContent(rs.getString(3));
				t.setTime(rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return t;
	}
	
	//�޸�Ӫҵʱ����Ϣ
	public boolean modifyWorkTime(ModifyWorkTimeForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update timedata set tdate=?,tday=?,tnight=? where no=? and tno=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getTdate());
			pst.setString(2, f.getTday());
			pst.setString(3, f.getTnight());
			pst.setString(4, f.getNo());
			pst.setString(5, f.getTno());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//ʵ�ֲ�ѯTM��Ϣ
	public ArrayList<TM> getAllTM()
	{
		ArrayList<TM> at=new ArrayList<TM>();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM news order by no desc";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				TM t=new TM();
				t.setNo(rs.getString(1));
				t.setTitle(rs.getString(2));
				t.setContent(rs.getString(3));	
				at.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return at;
	}
	
	//ʵ������TNews��Ϣ
	public boolean addTM(AddTMForm f)
	{
		boolean b=false;
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="INSERT INTO news values(?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, f.getNo());
			pst.setString(2, f.getTitle());
			pst.setString(3, f.getContent());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//��ѯһ��TM��Ϣ
	public TM getATM(String no)
	{
		TM t=new TM();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM news"
				          +" WHERE no=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, no);        //���кţ����Ĳ�����
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				t.setNo(rs.getString(1));
				t.setTitle(rs.getString(2));
				t.setContent(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return t;
	}
	
	//�޸�TM��Ϣ
	public boolean modifyTM(ModifyTMForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update news set title=?,content=? where no=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getTitle());
			pst.setString(2, f.getContent());
			pst.setString(3, f.getNo());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//ɾ��TMȤ��
	public boolean deleteTM(String no){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from news where no=?");
			pst.setString(1, no);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
	
	//ɾ�����»
	public boolean deleteActivity(String no){
		boolean b=false;
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;

		try {
			pst=con.prepareStatement("delete from activity where no=?");
			pst.setString(1, no);
			
			int i=pst.executeUpdate();
			if(i>0){
				b=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			close(pst);
			close(con);
		}	
		return b;
		}
}