package business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Message;

import struts.form.AddMessageForm;



public class MessageBusiness extends BaseBusiness {
//��������
	public boolean addMessage(AddMessageForm af,String uname){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement ps=null;
		try {
			ps=con.prepareStatement("insert into message values(?,?,?,?)");
			ps.setString(1, af.getId());
			ps.setString(2, af.getMes());
			ps.setString(3, af.getTime());
			ps.setString(4, uname);
			int i=ps.executeUpdate();
			if(i>0)                                 
				b=true;                             
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			close(ps);
			close(con);
   		}
		
		return b;
	}	
	
	//��ѯ����������
public ArrayList<Message> getMessages(){
		
		ArrayList<Message> al=new ArrayList<Message>();
		Connection con=(Connection) getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select * from message";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			while(rs.next()){
				Message mb=new Message();
				mb.setId(rs.getString(1));
				mb.setMes(rs.getString(2));
				mb.setTime(rs.getString(3));
				al.add(mb);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			close(rs);
			close(pst);
			close(con);
		}
	
		return al;
		
	}

//��ѯ�ҵ�����

public ArrayList<Message> getMyMessages(String username){
	
	ArrayList<Message> al=new ArrayList<Message>();
	Connection con=(Connection) getOneCon();
	PreparedStatement pst=null;
	ResultSet rs=null;
	try {
		String sql="select * from message where username=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, username);
		rs=pst.executeQuery();
		while(rs.next()){
			Message mb=new Message();
			mb.setId(rs.getString(1));
			mb.setMes(rs.getString(2));
			mb.setTime(rs.getString(3));
			al.add(mb);
		}
	} catch (Exception e) {
		// TODO: handle exception
	}finally{
		close(rs);
		close(pst);
		close(con);
	}

	return al;
	
}


//ɾ������
public boolean deleteMessage(String id){
	boolean b=false;
	Connection con=(Connection) getOneCon();
	PreparedStatement pst=null;

	try {
		pst=con.prepareStatement("delete from message where id=?");
		pst.setString(1, id);
		
		int i=pst.executeUpdate();
		if(i>0){
			b=true;
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		
		close(pst);
		close(con);
	}	
	return b;
	}
}
