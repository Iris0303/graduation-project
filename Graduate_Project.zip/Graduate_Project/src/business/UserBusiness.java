package business;
import java.sql.*;

import entity.Data;

import struts.form.LoginForm;
import struts.form.ModifyPWForm;
import struts.form.RegistForm;
import struts.form.UpdateDataForm;

public class UserBusiness extends BaseBusiness{
	//�ж��û����Ƿ����
	public boolean isUse(String uname){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM USERTABLE WHERE userName=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, uname);
			rs=pst.executeQuery();
			//�ж�����ֵ
			if(rs.next()){
				b=false;
			}else{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		    close(rs);
		    close(pst);
		    close(con);
		}
		return b;
		
	}
	
	//ʵ��ע�Ṧ��
	public boolean regist(RegistForm u){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		
		try {
			String sql="INSERT INTO usertable VALUES(?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getUname());
			pst.setString(2, u.getUpass());
			pst.setString(3, u.getId());
			pst.setString(4, u.getTelephone());
			pst.setString(5, u.getMail());
			pst.setString(6, u.getAddress());
			pst.setString(7, u.getPosition());
			pst.setString(8, u.getDescription());
			int n=pst.executeUpdate();
			if(n>0){
				b=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		    
		    close(pst);
		    close(con);
		}
		return b;
		
	}
	
	//ʵ�ֵ�¼����

	public boolean islogin(LoginForm u){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM USERTABLE WHERE userName=? and password=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getUname());
			pst.setString(2, u.getUpass());
			rs=pst.executeQuery();
			//�ж�����ֵ
			if(rs.next()){
				b=true;
			}else{
				b=false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		    close(rs);
		    close(pst);
		    close(con);
		}
		return b;
		
	}
	
	//�޸ĸ�������
	public boolean updatePassword(String uname,String u){
		boolean b=false;
		Connection con=getOneCon();
		PreparedStatement pst=null;
		try {
			String sql="update usertable set password=? where username=?";
			pst=con.prepareStatement(sql);
			
			pst.setString(1,u);
			pst.setString(2,uname);
			

			int n=pst.executeUpdate();
			if(n>0){
				b=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			close(pst);
			close(con);
		}
		return b;
		
	}
	//�õ��û���Ϣ
	public Data getInfo(String username)
	{
		Data f=new Data();
		Connection con=getOneCon();        //�������ݿ⣬�Ӹ���õ����Ӷ���
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select id,telephone,mail,address,position,description from usertable where username=?";
			pst=con.prepareStatement(sql);
			pst.setString(1, username);        //���кţ����Ĳ�����
			rs=pst.executeQuery();        //ִ�в�ѯ
			while(rs.next())
			{
				f.setId(rs.getString(1));
				f.setTelephone(rs.getString(2));
				f.setMail(rs.getString(3));
				f.setAddress(rs.getString(4));
				f.setPosition(rs.getString(5));
				f.setDescription(rs.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			close(rs);
			close(pst);
			close(con);
		}
		return f;
	}
	
	//�޸��û�����
	public boolean updatePassWord(String password, String username)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update usertable set password=? where username=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, password);
			pst.setString(2, username);
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
	
	//�޸��û���Ϣ
	public boolean updateData(UpdateDataForm f)
	{
		boolean b=false;
		
		PreparedStatement pst=null;
		Connection con=getOneCon();
		try {
			String sql="update usertable set telephone=?,mail=?,address=?,position=?, description=? where id=?";
			pst=con.prepareStatement(sql);
			//Ҫ�������ݿ��˳��
			pst.setString(1, f.getTelephone());
			pst.setString(2, f.getMail());
			pst.setString(3, f.getAddress());
			pst.setString(4, f.getPosition());
			pst.setString(5, f.getDescription());
			pst.setString(6, f.getId());
			int n=pst.executeUpdate();
			if(n>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close(pst);
			close(con);
		}
		return b;
	}
}
